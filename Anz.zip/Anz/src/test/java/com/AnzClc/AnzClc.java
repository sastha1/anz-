package com.AnzClc;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.base.HelperClass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AnzClc extends HelperClass {

	AnzClcPage objAnzClcPage;
	WebDriver driver;

	@Given("User is on the Anz calculator page")
	public void user_is_on_the_Anz_calculator_page() {
		driver = LaunchBrowser();
		objAnzClcPage = new AnzClcPage(driver);
	}

	@When("User enters the personal and expense details {string},{string},{string},{string},{string}")
	public void user_enters_the_personal_and_expense_details(String income, String otherincome, String Livingexpenses,
			String otherloanrepayments, String totalcreditcardlimits) {

		objAnzClcPage.calculateBorrowEstimation(income, otherincome, Livingexpenses, otherloanrepayments, totalcreditcardlimits);

	}

	@When("User clicks borrow estimation button")
	public void user_clicks_borrow_estimation_button() {

		objAnzClcPage.ClickAction(objAnzClcPage.getbtnBorrowCalculater());
	}

	@Then("Validate the generated estimation{string}")
	public void validate_the_generated_estimation(String Expected) throws InterruptedException {
		Thread.sleep(3000);
		String actual = objAnzClcPage.getborrowEstimatedAmt().getText();
		if (Expected.equals(actual)) {
			Assert.assertEquals("Estimated loan borrow amount does matches ", Expected, actual);
		} else {
			Assert.assertEquals("Estimated loan borrow amount does not matches ", Expected, actual);
		}

	}
	
	@When("User enters the personal and expense details and clicks estimate")
	public void user_enters_the_personal_and_expense_details_and_clicks_estimate() {
		user_enters_the_personal_and_expense_details("80000", "10000", "500", "100", "10000");
		user_clicks_borrow_estimation_button();
	}

	@When("User clicks start over button")
	public void user_clicks_start_over_button() throws InterruptedException {
		objAnzClcPage.fieldsReset();
	}

	@Then("Validate the resetted fields")
	public void validate_the_resetted_fields() {
		objAnzClcPage.ResetValidation();
	}
	
	@When("User enters only Living expense and clicks estimate {string}")
	public void user_enters_only_Living_expense_and_clicks_estimate(String Livingexpenses) {
		objAnzClcPage.enterOnlyLivingExp(Livingexpenses);
		objAnzClcPage.ClickAction(objAnzClcPage.getbtnBorrowCalculater());

	}

	@Then("Validate the unable to estimate message")
	public void validate_the_unable_to_estimate_message() throws InterruptedException {

		objAnzClcPage.unabletoExtimateValidation("//span[contains(text(),'Based')]");
	}

	@Then("Clear session")
	public void clearDriverSession() throws InterruptedException {
		driver.quit();
	}


	
}
